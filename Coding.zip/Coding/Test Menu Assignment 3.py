import sys
from backend import *

def menu():
    mes = "\n-=-=-Welcome to the-=-=-\n"
    mes+= "-=-=-=-=-=-=--=-=-=-=-=-\n"
    mes+= "------------------------\n"
    mes+= "-=-=Crime Likelihood=-=-\n"
    mes+= "------------------------\n"
    mes+= "-=-=-=-=-=-=--=-=-=-=-=-\n"
    mes+= "\n"
    sys.stdout.write(mes)
    me0 = "Please select from the below options"
    me0+= "[V]iew Data
    me0+= "[Q]uestionare
    me0+= "[E]xit
    sys.stdout.write(me0)
    inp1 = sys.stdin.readline().strip().lower()
    while inp1 != "e":
        #
        if inp1 == "v":
            #
            view_data()
        
        elif inp1 == "q":
            #
            questionare0()


#due to where you live you will need to keep expensive belongings out of site
