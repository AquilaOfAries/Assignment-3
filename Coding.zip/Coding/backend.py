import sys

def view_data():
    vd0 = "How would you like to sort the record.\n"
    vd0+= "[P]ostcode and suburb/\n"
    vd0+= "[L]ocality.\n"
    vd0+= "[T]ime commited.\n"
    vd0+= "[C]lass of crime.\n"
    vd0+= "[R]eturn to previous menu.\n"
    sys.stdout.write(vd0)
    inp2 = sys.stdin.readline().strip().lower()
    while inp2 != "r":
        if inp2 == "p":
            pass
        elif inp2 == "l":
            pass
        elif inp2 == "t":
            pass
        elif inp2 == "c":
            pass

def questionare0():
    q0 = "Please confirm if you are :\n"
    q0+= "[I]ndividual\n"
    q0+= "[B]usiness\n"
    q0+= "[R]eturn to previous menu.\n"
    sys.stdout.write(q0)
    inp3 = sys.stdin.readline().strip().lower()
    while inp3 != "r":
        if inp3 == "i":
            pass
        elif inp3 == "b":
            pass
    return inp3

def questionare1(inp3):
    q1 = "Please enter Postcode of the area in question: \n"
    q2 = "Please confirm suburb from list below.\n"
    sys.stdout.write(q1)
    inp4 = sys.stdin.readline().strip()
    #for r in range(0,len(temp)):
        #if inp4 == temp[r]:
            #sys.stdout.write(q2)
            #sys.stdout.write(temp[r])
            #inp5 = sys.stdin.readline().strip().lower()
    q3 = "Based on "+inp5+" your crime likelyhood is database figure\n"
    q4 = "chance of burglary %, chances of house robbed %, chances of being stabbed %\n"
    sys.stdout.write(q3)
    sys.stdout.write(q4)
    sys.stdout.write("Would you like to continue to get a more accurate result? [Y]/[N] \n")
    inp6 = sys.stdin.readline().strip().lower()
    if inp6 == "y" and inp3 == "b":
        #run next module
        business1()
    elif inp6 == "y" and inp3 == "i":
        #run next module
        personal1()
    else:
        sys.stdout.write("Returning to previous menu\n")
    return inp4, inp5

def personal1():
    p1 = "Please enter your nationality: \n"
    sys.stdout.write(p1)
    inpp1 = sys.stdin.readline().strip()
    sys.stdout.write("Would you like to continue to get a more accurate result? [Y]/[N] \n")
    inpp2 = sys.stdin.readline().strip().lower()
    if inpp2 == "y":
        personal2()
    else:
        sys.stdout.write("Based on your inputs so far your crime likelihood is database figure\n")
        sys.stdout.write("chance of burglary %, chances of robbed %, chances of being stabbed %\n")
    return inpp1

def personal2():
    p2 = "Please enter your age: \n"
    sys.stdout.write(p2)
    inpp3 = sys.stdin.readline().strip()
    sys.stdout.write("Would you like to continue to get a more accurate result? [Y]/[N] \n")
    inpp4 = sys.stdin.readline().strip().lower()
    if inpp4 == "y":
        personal3()
    else:
        sys.stdout.write("Based on your inputs so far your crime likelihood is database figure\n")
        sys.stdout.write("chance of burglary %, chances of robbed %, chances of being stabbed %\n")
    return inpp3

def personal3():
    p3 = "Please enter your living conditions: i.e. with someone or alone\n"
    sys.stdout.write(p3)
    inpp5 = sys.stdin.readline().strip()
    sys.stdout.write("Would you like to continue to get a more accurate result? [Y]/[N] \n")
    inpp6 = sys.stdin.readline().strip().lower()
    if inpp6 == "y":
        personal3()
    else:
        sys.stdout.write("Based on your inputs so far your crime likelihood is database figure\n")
        sys.stdout.write("chance of burglary %, chances of robbed %, chances of being stabbed %\n")
    return inpp5

def personal4():
    p4 = "Do you live in one of the below and type your responce: \n"
    p4+= "[A]partment\n [O]ld House\n [M]odern House\n [U]nit\n [T]ownhouse\n"    
    sys.stdout.write(p4)
    inpp7 = sys.stdin.readline().strip()
    p41 = "All questions answered please see final result and printout of all questions answered below\n"
    sys.stdout.write(p41)
    results_personal()
    return inpp7

def business1():
    b1 = "Please enter what type of business you are operating / planning to operate: \n"
    sys.stdout.write(b1)
    inpb1 = sys.stdin.readline().strip()
    sys.stdout.write("Would you like to continue to get a more accurate result? [Y]/[N] \n")
    inpb2 = sys.stdin.readline().strip().lower()
    if inpb2 == "y":
        business2()
    else:
        sys.stdout.write("Based on your inputs so far the chances of the business being burgled are database figure\n")
        sys.stdout.write("chance of burglary %, property damage %, out of hours burglary %\n")
    return inpb1

def business2():
    b2 = "Please enter how many staff you will have onsite during working hours: \n"
    sys.stdout.write(b2)
    inpb3 = sys.stdin.readline().strip()
    sys.stdout.write("Would you like to continue to get a more accurate result? [Y]/[N] \n")
    inpb4 = sys.stdin.readline().strip().lower()
    if inpb4 == "y":
        business3()
    else:
        sys.stdout.write("Based on your inputs so far the chances of the business being burgled are database figure\n")
        sys.stdout.write("chance of burglary %, property damage %, out of hours burglary %\n")
    return inpb3

def business3():
    b3 = "Please enter which security systems are in place for your company: \n"
    sys.stdout.write(b3)
    inpb5 = sys.stdin.readline().strip()
    sys.stdout.write("Would you like to continue to get a more accurate result? [Y]/[N] \n")
    inpb6 = sys.stdin.readline().strip().lower()
    if inpb6 == "y":
        business4()
    else:
        sys.stdout.write("Based on your inputs so far the chances of the business being burgled are database figure\n")
        sys.stdout.write("chance of burglary %, property damage %, out of hours burglary %\n")
    return inpb5

def business4():
    b4 = "Will your business have after Hours security patrols? \n"
    sys.stdout.write(b4)
    inpb7 = sys.stdin.readline().strip()
    b41 = "All questions answered please see final result and printout of all questions answered below\n"
    sys.stdout.write(b41)
    results_business()
    return inpb7

def results_personal(inp3,inp4,inp5,inpp1,inpp3,inpp5,inpp7):
    pass

def results_business(inp3,inp4,inp5,inpb1,inpb3,inpb5,inpb7):
    pass
